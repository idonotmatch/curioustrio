// schema.ts

export const API_KEY = 'Yc129c435-77ed-4584-8771-2ce5ad3954adE';
